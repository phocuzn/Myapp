package com.solution.fixmangapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.gson.Gson
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Timer
import kotlin.concurrent.timer
import kotlin.concurrent.thread

class MyVpnService : VpnService() {
    private val TAG = "MyVpnService"
    private var vpnInterface: ParcelFileDescriptor? = null
    private var isPacketManipulationActive = false
    private var config: NetCfg? = null
    private var autoOffTimer: Timer? = null
    private var vpnThread: Thread? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private val HARDCODED_CONFIG_JSON = """
      {"author":"Tele","autoOFF":true,"changeClientPackets":true,"changeServerPackets":false,"delayClientPackets":false,"deleteClientPackets":true,"deleteServerPackets":false,"desc":"👺","frequencyChangeClientPackets":100.0,"frequencyChangeServerPackets":98.721436,"skipSomeServerPackets":false,"title":"TP by. @\"👺","varAutoOFF":4.6,"varDelayClientPackets":0.0,"vpn":0}
    """.trimIndent()
    private val NOTIFICATION_ID = 1
    private val NOTIFICATION_CHANNEL_ID = "VPN_SERVICE_CHANNEL"

    companion object {
        var isRunning = false
        const val ACTION_CONNECT = "ACTION_CONNECT"
        const val ACTION_DISCONNECT = "ACTION_DISCONNECT"
        const val ACTION_ACTIVATE_MANIPULATION = "ACTION_ACTIVATE_MANIPULATION"
        const val BROADCAST_MANIPULATION_STATE_CHANGED = "BROADCAST_MANIPULATION_STATE_CHANGED"
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        initNetworkCallback()
    }

    private fun initNetworkCallback() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                super.onLost(network)
                Log.w(TAG, "Mạng đã mất! Tự động dừng VPN để đảm bảo an toàn.")
                stopVpn()
            }
        }
        connectivityManager.registerDefaultNetworkCallback(networkCallback!!)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                if (vpnThread == null || !vpnThread!!.isAlive) {
                    vpnThread = thread {
                        loadConfig()
                        startVpn()
                    }
                }
            }
            ACTION_DISCONNECT -> stopVpn()
            ACTION_ACTIVATE_MANIPULATION -> if (config != null && !isPacketManipulationActive) startPacketManipulation()
        }
        return START_STICKY
    }

    private fun startVpn() {
        startForeground(NOTIFICATION_ID, createNotification())
        val builder = Builder().setSession("MyVpnSession")
            .addAddress("10.8.0.2", 24)
            .addRoute("0.0.0.0", 0)
            .addAddress("fd00:1:2:3::2", 64)
            .addRoute("::", 0)
            .addDnsServer("8.8.8.8")
            .setBlocking(false)
        try {
            vpnInterface = builder.establish()
            Log.i(TAG, "VPN interface established.")
            val vpnInputStream = FileInputStream(vpnInterface!!.fileDescriptor)
            val vpnOutputStream = FileOutputStream(vpnInterface!!.fileDescriptor)
            val buffer = ByteArray(32767)
            while (true) {
                if (Thread.interrupted()) { throw InterruptedException() }
                val readBytes = vpnInputStream.read(buffer)
                if (readBytes > 0) {
                    if (!isPacketManipulationActive || config?.deleteClientPackets != true) {
                        vpnOutputStream.write(buffer, 0, readBytes)
                    }
                } else if (readBytes == -1) {
                    break
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi trong luồng VPN", e)
        } finally {
            Log.i(TAG, "Luồng VPN kết thúc, tiến hành dọn dẹp.")
            stopVpn()
        }
    }

    private fun stopVpn() {
        Log.d(TAG, "stopVpn() được gọi.")
        autoOffTimer?.cancel()
        vpnThread?.interrupt()
        vpnThread = null
        try { vpnInterface?.close() } catch (e: Exception) { /* Bỏ qua lỗi khi đóng */ }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isRunning = false
        if (networkCallback != null) {
            val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            connectivityManager.unregisterNetworkCallback(networkCallback!!)
        }
        super.onDestroy()
        Log.i(TAG, "MyVpnService đã bị hủy.")
    }

    private fun loadConfig() {
        try {
            config = Gson().fromJson(HARDCODED_CONFIG_JSON, NetCfg::class.java)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "VPN Service Channel", NotificationManager.IMPORTANCE_DEFAULT)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    private fun createNotification(): Notification {
        createNotificationChannel()
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("VPN Service Running")
            .setContentText("Connection is active")
            .setSmallIcon(R.drawable.ic_lock_closed)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun startPacketManipulation() {
        isPacketManipulationActive = true
        broadcastManipulationState(true)
        if (config?.autoOFF == true) {
            val delay = (config!!.varAutoOFF * 1000).toLong()
            autoOffTimer?.cancel()
            autoOffTimer = timer(initialDelay = delay, period = delay) {
                stopPacketManipulation()
                this.cancel()
            }
        }
    }

    private fun stopPacketManipulation() {
        isPacketManipulationActive = false
        broadcastManipulationState(false)
    }

    private fun broadcastManipulationState(isActive: Boolean) {
        sendBroadcast(Intent(BROADCAST_MANIPULATION_STATE_CHANGED).putExtra("isActive", isActive))
    }
}