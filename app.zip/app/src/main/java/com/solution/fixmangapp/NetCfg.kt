package com.solution.fixmangapp

data class NetCfg(
    val autoOFF: Boolean,
    val deleteClientPackets: Boolean,
    val varAutoOFF: Double
)