package com.solution.fixmangapp

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import kotlin.math.abs

class FloatingWidgetService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var lockIcon: ImageView
    private lateinit var params: WindowManager.LayoutParams
    private val manipulationStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == MyVpnService.BROADCAST_MANIPULATION_STATE_CHANGED) {
                updateIcon(intent.getBooleanExtra("isActive", false))
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_widget, null)
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager.addView(floatingView, params)
        lockIcon = floatingView.findViewById(R.id.lock_icon)
        addDragAndDropListener()
        val filter = IntentFilter(MyVpnService.BROADCAST_MANIPULATION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(manipulationStateReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(manipulationStateReceiver, filter)
        }
    }

    private fun addDragAndDropListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        floatingView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    return@setOnTouchListener true
                }
                MotionEvent.ACTION_UP -> {
                    val xDiff = event.rawX - initialTouchX
                    val yDiff = event.rawY - initialTouchY
                    if (abs(xDiff) < 5 && abs(yDiff) < 5) {
                        startService(Intent(this, MyVpnService::class.java).apply { action = MyVpnService.ACTION_ACTIVATE_MANIPULATION })
                    }
                    return@setOnTouchListener true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, params)
                    return@setOnTouchListener true
                }
            }
            return@setOnTouchListener false
        }
    }

    private fun updateIcon(isActive: Boolean) {
        lockIcon.setImageResource(if (isActive) R.drawable.ic_lock_open else R.drawable.ic_lock_closed)
    }

    override fun onDestroy() {
        super.onDestroy()
        windowManager.removeView(floatingView)
        unregisterReceiver(manipulationStateReceiver)
    }
}