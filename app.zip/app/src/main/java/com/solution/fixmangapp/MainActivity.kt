package com.solution.fixmangapp

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val VPN_REQUEST_CODE = 101
    private val OVERLAY_REQUEST_CODE = 102
    private val PERMISSION_REQUEST_CODE = 103
    private lateinit var btnOn: Button
    private lateinit var btnOff: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnOn = findViewById(R.id.btnOn)
        btnOff = findViewById(R.id.btnOff)
        btnOn.setOnClickListener { requestPermissionsAndStart() }
        btnOff.setOnClickListener { stopServices() }
    }

    override fun onResume() {
        super.onResume()
        updateButtonStates()
    }

    private fun updateButtonStates() {
        val isServiceRunning = MyVpnService.isRunning
        btnOn.isEnabled = !isServiceRunning
        btnOff.isEnabled = isServiceRunning
    }

    private fun requestPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, OVERLAY_REQUEST_CODE)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), PERMISSION_REQUEST_CODE)
                return
            }
        }
        startVpn()
    }

    private fun startVpn() {
        val vpnIntent = VpnService.prepare(this)
        if (vpnIntent != null) {
            startActivityForResult(vpnIntent, VPN_REQUEST_CODE)
        } else {
            onActivityResult(VPN_REQUEST_CODE, Activity.RESULT_OK, null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OVERLAY_REQUEST_CODE) {
            if (Settings.canDrawOverlays(this)) {
                requestPermissionsAndStart()
            } else {
                Toast.makeText(this, "Overlay permission is required", Toast.LENGTH_SHORT).show()
            }
        } else if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            startServices()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startVpn()
            } else {
                Toast.makeText(this, "Notification permission is required", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startServices() {
        val vpnServiceIntent = Intent(this, MyVpnService::class.java).apply { action = MyVpnService.ACTION_CONNECT }
        startService(vpnServiceIntent)
        startService(Intent(this, FloatingWidgetService::class.java))
        updateButtonStates()
    }

    private fun stopServices() {
        val vpnServiceIntent = Intent(this, MyVpnService::class.java).apply { action = MyVpnService.ACTION_DISCONNECT }
        startService(vpnServiceIntent)
        stopService(Intent(this, FloatingWidgetService::class.java))
        updateButtonStates()
    }
}